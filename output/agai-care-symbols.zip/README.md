# Agai custom care symbols

Six original vector compositions inspired by the supplied reference's flowing blue human silhouette and pointed green leaves. The reference image and its watermark are not embedded or traced. Artwork is hand-authored as filled SVG Bézier paths and circles; the presentation is rendered from those same SVG shapes.

## Files and presentation order

Left to right, top row:
1. `01-pain-and-stiffness.svg`
2. `02-injury-and-rehabilitation.svg`
3. `03-return-to-sport.svg`

Left to right, bottom row:
4. `04-pregnancy-and-womens-health.svg`
5. `05-walking-and-balance.svg`
6. `06-stroke-and-movement-recovery.svg`

Each individual SVG has a transparent background and a square `viewBox="0 0 256 256"`. There are no embedded bitmaps, external assets, fonts, strokes, gradients, shadows, borders, or watermarks. Artwork uses only #006C9F, #48B20B, and #78C92D. Accessible names are included as nonvisual SVG attributes.

`agai-six-care-symbols.png` and `.svg` are the matching 1536 × 1024, three-column by two-row presentation on white, with no visible labels. `size-proof-64px-48px.png` shows actual 64 px artwork in the upper row and 48 px artwork in the lower row.

## Website use

The six SVG assets are also saved under `public/images/care-symbols/`. For an icon beside an existing visible card heading:

```tsx
<img
  src="/images/care-symbols/01-pain-and-stiffness.svg"
  width="64"
  height="64"
  alt=""
/>
```

Use meaningful alt text when the icon is the only label. Render on white or a very light surface for the intended color contrast. Do not stretch the square aspect ratio. Existing website cards are not changed by the asset generation script.

To regenerate the set and presentation: `node scripts/create-care-icons.mjs`.

## Design brief

Primary visual reference: the user-supplied blue human/green-leaf wellness mark. Create six original, cohesive logo-style physiotherapy symbols: upward stretch, supported rehabilitation, running athlete, maternal pregnancy curve, balanced forward step, and coordinated movement recovery. Use circular blue heads, expressive tapered blue bodies and limbs, pointed green organic ribbons, clean negative space, solid prescribed colors, transparent square canvases, and legibility at 48–64 px. No visible text, outlines, gradients, shadows, borders, or watermark. Deliver six editable SVGs and a matching white 3 × 2 presentation.
